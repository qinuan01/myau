package myau.init;

public class Initializer {
    public Initializer() {
        System.out.println("Meow!");
    }
}
