package myau.enums;

public enum FloatModules {
    NO_SLOW
}
