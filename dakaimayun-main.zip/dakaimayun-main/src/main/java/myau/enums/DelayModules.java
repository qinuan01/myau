package myau.enums;

public enum DelayModules {
    NONE,
    VELOCITY,
    BED_NUKER
}
