package myau.enums;

public enum BlinkModules {
    NONE,
    ANTI_VOID,
    AUTO_BLOCK,
    BLINK,
    NO_FALL,
    NO_SLOW
}
