package myau.events;

import myau.event.events.Event;

public class MoveInputEvent implements Event {
}
