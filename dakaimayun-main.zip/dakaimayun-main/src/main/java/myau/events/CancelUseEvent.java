package myau.events;

import myau.event.events.callables.EventCancellable;

public class CancelUseEvent extends EventCancellable {
}
