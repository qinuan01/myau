package myau.events;

import myau.event.events.callables.EventCancellable;

public class LeftClickMouseEvent extends EventCancellable {
}
