package myau.events;

import myau.event.events.Event;

public class ResizeEvent implements Event {
}
