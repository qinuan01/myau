package myau.data;

public class Box<T> {
    public T value;

    public Box(T value) {
        this.value = value;
    }
}
