package myau.module.modules;

import myau.event.EventTarget;
import myau.event.types.EventType;
import myau.events.TickEvent;
import myau.module.Module;
import myau.property.properties.BooleanProperty;
import myau.property.properties.IntProperty;
import myau.util.ItemUtil;
import myau.util.KeyBindUtil; 
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.settings.KeyBinding; 
import net.minecraft.init.Blocks;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.MovingObjectPosition;
import net.minecraft.util.MovingObjectPosition.MovingObjectType;
import net.minecraft.client.gui.GuiChat; // 引入 GuiChat
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.inventory.GuiContainer;
import net.minecraft.client.gui.inventory.GuiContainerCreative;

public class AutoMiner extends Module {

    private final Minecraft mc = Minecraft.getMinecraft();
    
    // --- 自动行走/挖掘状态 ---
    private BlockPos miningTargetPos = null;
    private int walkDelayCounter = 0;
    
    // --- AutoMiner 属性 ---
    public final BooleanProperty turnFromBedrock = new BooleanProperty("Turn-From-Bedrock", true);
    public final BooleanProperty autoWalk = new BooleanProperty("Auto-Walk", false);
    public final IntProperty walkTicks = new IntProperty("Walk-Ticks", 2, 1, 5); 

    // --- AutoTool 属性 ---
    private int currentToolSlot = -1;
    private int previousSlot = -1;
    private int toolDelayCounter = 0;
    public final IntProperty switchDelay = new IntProperty("Tool-Delay", 0, 0, 5); 
    public final BooleanProperty switchBack = new BooleanProperty("Tool-Switch-Back", true); 

    public AutoMiner() {
        super("AutoMiner", false);
    }
    
    // --- 移植 InvWalk 的关键逻辑 ---

    /**
     * 检查当前是否在允许运行 AutoMiner 的 GUI 或聊天界面。
     * * @return true 如果当前屏幕为空 (游戏中), GuiChat, 或 GuiContainer (背包/箱子)
     */
    private boolean isInvWalkScreen() {
        GuiScreen current = mc.currentScreen;
        
        // 1. 无 GUI (游戏中)
        if (current == null) {
            return true;
        }
        
        // 2. 聊天界面（通常允许移动）
        if (current instanceof GuiChat) {
            return true;
        }
        
        // 3. 容器 GUI (背包、箱子、熔炉等)
        if (current instanceof GuiContainer) {
            // 排除创造模式的 GUI，因为其物品操作机制不同
            return !(current instanceof GuiContainerCreative);
        }
        
        // 4. 其他任何 GUI (例如 ESC 菜单, Mod 配置界面) 均禁用
        return false;
    }
    
    /**
     * 安全地按下/释放 W 键 (前进)。
     */
    private void pressWKey(boolean state) {
        KeyBindUtil.setKeyBindState(mc.gameSettings.keyBindForward.getKeyCode(), state);
    }
    
    /**
     * 安全地按下/释放 左键 (攻击/挖掘)。
     */
    private void pressAttackKey(boolean state) {
        KeyBindUtil.setKeyBindState(mc.gameSettings.keyBindAttack.getKeyCode(), state);
    }

    /**
     * 释放所有被模块控制的按键。
     */
    private void releaseKeys() {
        this.pressWKey(false);
        this.pressAttackKey(false);
    }

    @Override
    public void onDisabled() {
        super.onDisabled();
        
        this.releaseKeys();
        
        if (this.switchBack.getValue() && this.previousSlot != -1) {
             mc.thePlayer.inventory.currentItem = this.previousSlot;
        }
        this.currentToolSlot = -1;
        this.previousSlot = -1;
        this.toolDelayCounter = 0;
        this.miningTargetPos = null;
        this.walkDelayCounter = 0;
    }

    @EventTarget
    public void onTick(TickEvent event) {
        if (!this.isEnabled() || event.getType() != EventType.PRE) {
            return;
        }

        if (mc.thePlayer == null || mc.theWorld == null || !this.isInvWalkScreen()) {
            // 【关键】如果不处于可运行的屏幕（例如 ESC 菜单），则停止所有操作并退出
            this.releaseKeys();
            return;
        }
        
        // --- 1. 挖掘完成后的自动行走逻辑 (优先级最高) ---
        if (walkDelayCounter > 0) {
            
            this.pressWKey(true);
            this.pressAttackKey(false); // 行走时释放左键
            
            walkDelayCounter--;
            
            if (walkDelayCounter == 0) {
                this.pressWKey(false); // 行走结束，释放 W 键
            }
            return;
        }
        
        // 确保没有在行走时，W 键是释放的 
        this.pressWKey(false);


        // --- 2. 检查挖掘完成并触发行走 ---
        if (miningTargetPos != null) {
            if (mc.theWorld.getBlockState(miningTargetPos).getBlock() == Blocks.air) {
                miningTargetPos = null;
                if (autoWalk.getValue()) {
                    walkDelayCounter = walkTicks.getValue(); 
                }
                return; 
            }
        }


        // --- 3. 瞄准和工具/挖掘逻辑 ---
        MovingObjectPosition objectMouseOver = mc.objectMouseOver;
        boolean isLookingAtBlock = objectMouseOver != null 
                && objectMouseOver.typeOfHit == MovingObjectType.BLOCK 
                && !mc.thePlayer.isUsingItem();

        if (isLookingAtBlock) {
            BlockPos targetPos = objectMouseOver.getBlockPos();
            
            // 检查是否是基岩
            if (mc.theWorld.getBlockState(targetPos).getBlock() == Blocks.bedrock) {
                if (turnFromBedrock.getValue()) {
                    turnAway();
                }
                this.handleToolReset(false); 
                this.pressAttackKey(false); // 遇到基岩释放左键
                return;
            }
            
            // A. AutoTool 逻辑：切换到最佳工具 
            boolean canSwitch = this.toolDelayCounter >= this.switchDelay.getValue();

            if (canSwitch) {
                int bestSlot = ItemUtil.findInventorySlot(
                        mc.thePlayer.inventory.currentItem, 
                        mc.theWorld.getBlockState(targetPos).getBlock()
                );

                if (mc.thePlayer.inventory.currentItem != bestSlot) {
                    if (this.previousSlot == -1) {
                        this.previousSlot = mc.thePlayer.inventory.currentItem;
                    }
                    mc.thePlayer.inventory.currentItem = this.currentToolSlot = bestSlot;
                }
            }
            this.toolDelayCounter++;
            

            // B. 持续按住左键 (攻击键)
            this.pressAttackKey(true); 

            // C. 记录挖掘目标
            miningTargetPos = targetPos; 

        } else {
            // C. 没有瞄准方块时：释放攻击键、回切和重置逻辑
            this.pressAttackKey(false); 
            this.handleToolReset(true);
        }
    }
    
    // --- 辅助方法 (保持不变) ---
    private void handleToolReset(boolean doSwitchBack) {
        if (doSwitchBack && this.switchBack.getValue() && this.previousSlot != -1) {
            mc.thePlayer.inventory.currentItem = this.previousSlot;
        }
        this.currentToolSlot = -1;
        this.previousSlot = -1;
        this.toolDelayCounter = 0;
    }

    private void turnAway() {
        EntityPlayerSP player = mc.thePlayer;
        EnumFacing facing = player.getHorizontalFacing();
        float targetYaw = player.rotationYaw; 

        switch (facing) {
            case NORTH:
                targetYaw = -90.0f; 
                break;
            case EAST:
                targetYaw = 0.0f;    
                break;
            case SOUTH:
                targetYaw = 90.0f;   
                break;
            case WEST:
                targetYaw = 180.0f; 
                break;
        }
        
        player.rotationYaw = targetYaw;
    }
}
